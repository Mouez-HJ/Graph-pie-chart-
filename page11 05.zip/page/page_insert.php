<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <!--[if lt IE 7]><html class="ie9 ie8 ie7 ie6" lang="en"><![endif]-->
    <!--[if IE 7]><html class="ie9 ie8 ie7" lang="en"><![endif]-->
    <!--[if IE 8]><html class="ie9 ie8" lang="en"><![endif]-->
    <!--[if IE 9]><html class="ie9" lang="en"><![endif]-->
    <!--[if gt IE 9]><!--><html lang="fr"><!--<![endif]-->
    <head>
        <title>BaseDemo - HorizontalNav</title>
        <link rel="stylesheet" href="bd.styles.css">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Afficher / Cacher une boite div en javascript</title>
        <link rel="stylesheet" media="all" title="style de la page" href="afficher_cacher_div.css" />
        <script type="text/javascript" src="afficher_cacher_div.js"></script>
       <!--Load the AJAX API-->
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script type="text/javascript">

        // Load the Visualization API and the piechart package.
        google.charts.load('current', {'packages':['corechart']});

        // Set a callback to run when the Google Visualization API is loaded.
        google.charts.setOnLoadCallback(pie_chart);
        google.charts.setOnLoadCallback(column_chart);
        google.charts.setOnLoadCallback(bar_chart);
        google.charts.setOnLoadCallback(line_chart);
        </script> 
        <!-- fichier ou il y a la fonction du graph --->  
        <script type="text/javascript" src="fonctiongraph.js"></script>   
        <!-- CSS Test Zone -->    
        <style></style>
    </head>
    <body>
        <div class="wrapper">
            <div class="page">
                <header class="header">
                  <p></p>
                </header>
                <button name="bouton" type="button" onclick="pie_chart();"></button>
                <div id="piechart_div" >
                    <script>
                        pie_chart;
                    </script>
                    
                </div>
            </div>
        </div>
    </body>
    <!-- jQuery -->
    <script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
    <script>!window.jQuery && document.write(unescape('%3Cscript src="bd.jquery.min.js"%3E%3C/script%3E'))</script>

    <!-- JavaScript -->
    <script src="bd.ui.js"></script>
    <script src="jquery.horizontalNav.js"></script>

    <!-- JavaScript Test Zone -->
    <script>
    $(document).ready(function() {
      $('.full-width').horizontalNav();

    });
    </script>
    <script>
        window.onload = pie_chart;
    </script>
     <!--Div that will hold the pie chart-->
        <!--<div style="font: 21px arial; padding: 10px 0 0 100px;">Pie Chart</div>
       <div id="piechart_div"></div>--> 
</html>