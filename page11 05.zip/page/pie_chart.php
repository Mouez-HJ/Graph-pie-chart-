<?php
include('db.php');
$tab = array();
$sql = "select * from courses";
$query = mysql_query($sql);
while($result = mysql_fetch_array($query))
{
    //$tab_2D = array();
    //$tab_2D[0] = $result['course_name'];
   // $tab_2D[1] = $result['number'];
  //echo $result['course_name'].'<br />';
    //$tab[]=$tab_2D;
    
    $rows[]=array("c"=>array("0"=>array("v"=>$result['course_name'],"f"=>NULL),"1"=>array("v"=>(int)$result['number'],"f" =>NULL)));
    
    //var image = canvas.toDataURL(); 
    //newImag
    
}
//var_dump($tab);

echo $format = '{
"cols":
[
{"id":"","label":"Subject","pattern":"","type":"string"},
{"id":"","label":"Number","pattern":"","type":"number"}
],
"rows":'.json_encode($rows).'}';

	


?>








