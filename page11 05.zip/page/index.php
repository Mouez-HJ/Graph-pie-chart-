<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<!--[if lt IE 7]><html class="ie9 ie8 ie7 ie6" lang="en"><![endif]-->
<!--[if IE 7]><html class="ie9 ie8 ie7" lang="en"><![endif]-->
<!--[if IE 8]><html class="ie9 ie8" lang="en"><![endif]-->
<!--[if IE 9]><html class="ie9" lang="en"><![endif]-->
<!--[if gt IE 9]><!--><html lang="fr"><!--<![endif]-->
<head>
    <title>BaseDemo - HorizontalNav</title>
    <link rel="stylesheet" href="bd.styles.css">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Afficher / Cacher une boite div en javascript</title>
    <link rel="stylesheet" media="all" title="style de la page" href="afficher_cacher_div.css" />
    <script type="text/javascript" src="afficher_cacher_div.js"></script>
   <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
     <!-- fichier ou il y a la fonction du graph --->  
    <script type="text/javascript" src="fonctiongraph.js"></script>
    <script type="text/javascript">
    
    // Load the Visualization API and the piechart package.
    google.charts.load('current', {'packages':['corechart']});
      
    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(pie_chart);
    google.charts.setOnLoadCallback(column_chart);
    google.charts.setOnLoadCallback(bar_chart);
    google.charts.setOnLoadCallback(line_chart);
    </script> 
      
    <!-- CSS Test Zone -->    
    <style></style>
</head>
<body>
<body>

  <div class="wrapper">
    <div class="page">
      <header class="header">
          <p></p>
      </header>      
      <div class="sep"><span class="left-arrow arrow"></span><span class="right-arrow arrow"></span></div>
      <div class="demo" id="demo-one">
        <div class="description">
          <h2>Annonce </h2>
          <p>PALAISEAU (91) VIAGER OCCUPE HOMME 86 ans / DAME 82 ans. Dans la Résidence du PARC D'ARDENAY recherchée pour son calme et dans la verdure, un appartement type F3 d'environ 60m˛ traversant composé d'une entrée avec placard, un séjour donnant sur grand balcon/terrasse, une salle ŕ manger (possibilité 2čme chambre), cuisine séparée avec cellier, chambre sur balcon (calme, verdure), salle de bains, WC séparés. Cave en sous-sol. Proximité du RER B "Palaiseau" . Proximité écoles: Camille Claudel, César Franck et Joliot Curie Calculs viager: Décôte (DUH) : 39 % Bouquet : 28 % Rente cumulée : 33 % Conditions de la vente : VALEUR VÉNALE DU BIEN : 246100 € / Valeur Occupée (prix d'achat) : 140 300 BOUQUET : 86 100 € / Honoraires ŕ la charge du vendeur RENTE MENSUELLE : 538 € indexées / RÉF : 3479V</p>
        </div><!-- .description -->
        <nav class="subnav tabs">
          <ul>
            <li class="active"><a href="#panel-1" onClick="recupererFichier('graph.php','panel-1');">Caractéristiques</a></li>
            <li><a href="#panel-2" >localisation</a></li>
            <li><a href="#panel-3">Analyse</a></li>
            <li><a href="#panel-4">Autre</a></li>
          </ul>
        </nav>
          <div class="panels">
              <div class="panel caracteristique" id="panel-1">
                  <p>teste de l'affichage de 1 page </p>
                  <div id="piechar"></div>
                  <a href="#" onClick="recupererFichier('graph.php','panel-2');">Lien</a>     
              </div>
              <div class="panel localisation" id="panel-2">
                  <script type="text/javascript"> pie_chart;</script>  
                  <p>teste de l'affichage de 2 page </p>
              </div>
               <div class="panel analyse" id="panel-3">    
                   <div style="font: 21px arial; padding: 10px 0 0 100px;">Pie Chart</div>
                   <div id="piechart_div">
                       <script>
                       pie_chart;
                       </script>
                   </div> 
              </div>
                    <div class="panel autre" id="panel-4">
                  <p>teste de l'affichage de 4 page </p>
                  <a href="../../graph.php"></a>
              </div>
          </div>
      </div><!-- .demo -->
      <div class="sep"><span class="left-arrow arrow"></span><span class="right-arrow arrow"></span></div>
     </div><!-- .options -->
     <div class="sep"><span class="left-arrow arrow"></span><span class="right-arrow arrow"></span></div>
     <div class="fallback">
     </div><!-- .description -->
      </div><!-- .fallback -->
    </div><!-- .page -->
<!-- jQuery -->
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<script>!window.jQuery && document.write(unescape('%3Cscript src="bd.jquery.min.js"%3E%3C/script%3E'))</script>

<!-- JavaScript -->
<script src="bd.ui.js"></script>
<script src="jquery.horizontalNav.js"></script>

<!-- JavaScript Test Zone -->
<script>
$(document).ready(function() {
  $('.full-width').horizontalNav();
   
});
</script>
    
 <!--Div that will hold the pie chart-->
	<!--<div style="font: 21px arial; padding: 10px 0 0 100px;">Pie Chart</div>
   <div id="piechart_div"></div>--> 
</body>
</html>
