

function pie_chart() {
          var jsonData = $.ajax({
              url: "pie_chart.php",
              dataType: "json",
              async: false
              }).responseText;

          // Create our data table out of JSON data loaded from server.
         // alert(jsonData);return false;
          var data = new google.visualization.DataTable(jsonData);

          // Instantiate and draw our chart, passing in some options.
          var chart = new google.visualization.PieChart(document.getElementById('piechart_div'));
          chart.draw(data, {width: 400, height: 240});

            // convertire chart a chaine base64
             var chart = new google.visualization.PieChart(document.getElementById('chart_id').toDataURL('image/png'));
            var url_base64 = new google.visualization.PieChart(document.getElementById('chart_id').toDataURL('image/png'));
             chart.draw(data, {width: 400, height: 240});
        }
